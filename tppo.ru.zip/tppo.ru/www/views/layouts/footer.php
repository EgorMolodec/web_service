<footer id="footer" class="sel col">
	<p>&nbsp;</p>
	<div class="child">
		<address style="color:white">
			<p>При возникновении вопросов обращаться по почте: </p>
			<a href="mailto:nsablina15@gmail.com" style="font-style:italic">Заказчик</a>
		</address>
	</div>
	<div class="child1">
		<p style="text-align:right;">Copyright&copy;2019</p>
	</div>
</footer>

<script src="../../template/js/bootstrap.min.js"></script>
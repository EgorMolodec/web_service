<?php include ROOT . '/views/layouts/header_admin.php'; ?>

<section>
    <div class="container">
	<p>&nbsp;</p>
        <div class="row">
            <br/>
            <div>
				<h4>Удалить задание </h4>
				<p>Вы действительно хотите удалить это задание?</p>
				<form method="post">
					<input type="submit" class="btn btn-otch" name="submit" value="Удалить" />
				</form>
            </div>
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer_admin.php'; ?>


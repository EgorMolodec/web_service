<?php include ROOT . '/views/layouts/header_admin.php'; ?>

<section>
    <div class="container">
	<p>&nbsp;</p>
        <div class="row">
            <br/>
            <h4>Редактировать задание</h4>
            <br/>
            <div class="col-lg-4">
                <div class="login-form">
                    <form action="#" method="post" enctype="multipart/form-data">
                        <p>Название задания</p>
                        <input type="text" name="name" placeholder="" value="<?php echo $task['txtTaskName']; ?>">
                        <p>&nbsp;</p>
                        <p>Описание</p>
                        <input type="text" name="description" placeholder="" value="<?php echo $task['txtTaskInfo']; ?>">
                        <p>&nbsp;</p>
                        <p>Пример</p>
                        <input type="file" name="example" placeholder="" value="">
                        <p>&nbsp;</p>
						                       
                        <div class="col-sm-12">
                           
                            <?php 
                                   $path =  "/upload/" . $course['txtCourseLatName'] . "/" . $task['txtTaskLatName'] . "/example";
                                   $result = array(); 

                                   if (file_exists(ROOT . $path)) {
                                       $cdir = scandir(ROOT . $path); 
                                       foreach ($cdir as $key => $value) 
                                       { 
                                          if (!in_array($value,array(".",".."))) 
                                          { 
                                             if (is_dir(ROOT . $path . DIRECTORY_SEPARATOR . $value)) 
                                             { 
                                                $result[$value] = dirToArray(ROOT . $path . DIRECTORY_SEPARATOR . $value); 
                                             } 
                                             else 
                                             { 
                                                $result[] = $value; 
                                             } 
                                          } 
                                       }

                                       echo ' <h5>Пример</h5>';
									   $i=1;
                                       foreach ($result as $file){
										$path = "/upload/" . $course['txtCourseLatName'] . "/" . $task['txtTaskLatName'] . "/example";
                                           echo "<a href='/task/exDelete" . $path . "/" . $task['intTaskID'] . "/" . $file . "' style='color:blue' id='".$i."'>" . $file . "</a>" . "</br>";
										   $i++;
                                       }
                                   }
                                   
                            ?>
                            
                        </div>
						
                        <input type="submit" name="submit" class="btn btn-new" value="Сохранить">
                        <br/><br/>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer_admin.php'; ?>


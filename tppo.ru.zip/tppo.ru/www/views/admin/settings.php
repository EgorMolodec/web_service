<?php include ROOT . '/views/layouts/header_admin.php'; ?>

<section>
    <div class="wrapper">
        <div class="content">
            
            <p>&nbsp;</p>
            <div style="margin-left:40px">
                <button type="button" class="btn btn-primary ">Назначить преподавателя</button>
                <p>&nbsp;</p>
                <button type="button" class="btn btn-primary">Настройка степени уникальности</button>
                <p>&nbsp;</p>
                <button type="button" class="btn btn-primary">Настройка временного промежутка</button>
                <p>&nbsp;</p>
                <button type="button" class="btn btn-primary" style="background-color: #FFD700; border: 2px solid #FFD700; color:black">Сохранить</button>
                <p>&nbsp;</p>
            </div>

            
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer_admin.php'; ?>
<?php include ROOT . '/views/layouts/header_admin.php'; ?>

<section>
    <div class="wrapper">
        <div class="row">
            <br/>
            <p>Настройки</p>
            <br/>
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer_admin.php'; ?>
<?php
return array(
    'host' => '127.0.0.1',
    'dbname' => 'servis',
    'user' => 'root',
    'password' => '',            
);
<?php
return array(
    'host' => 'localhost',
    'dbname' => 'servis',
    'user' => 'root',
    'password' => '',            
);